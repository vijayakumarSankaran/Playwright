import { expect, Page } from "@playwright/test";
import PlaywrightWrapper from "../helper/wrapper/PlaywrightWrappers";


export default class PopupPage {
    private base: PlaywrightWrapper
    constructor(private page: Page) {
        this.base = new PlaywrightWrapper(page);
    }

    private Elements = {
        alertPopupBtn: "//b[text()='Alert Popup']",
        errorMessage: "alert"
    }

    async clickLoginButton() {
        await this.base.waitAndClick(this.Elements.alertPopupBtn);
    }

    getErrorMessage() {
        return this.page.getByRole("alert");
    }

    
}