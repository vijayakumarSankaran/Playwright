import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../hooks/pageFixture";
import { log } from "winston";


setDefaultTimeout(60 * 1000 * 2)

Given('User navigates to the practices-automation application', async function () {
    await fixture.page.goto(process.env.BASEURL);
    fixture.logger.info("Navigated to the application")
})

Given('User click on the window link', async function () {
    await fixture.page.locator("//a[text()='Window Operations']").click();
});

When('User click on the new tab button', async function () {
    // await fixture.page.locator("//b[text()='New Tab']").click();
    // await fixture.page.waitForLoadState();
    // fixture.logger.info("Waiting for 2 seconds")
    // await fixture.page.waitForTimeout(5000);
    console.log("test");
    
});


Then('new window should be display', async function () {
    const [newWindow] = await Promise.all([
        await fixture.page.waitForEvent("load"),
        await fixture.page.locator("//b[text()='New Tab']").click(),
        await fixture.page.waitForLoadState(),
        fixture.logger.info("Waiting for 2 seconds"),
        await fixture.page.waitForTimeout(7000)  
     ]);
     console.log("hi"+newWindow.url());
     await fixture.page.waitForTimeout(7000);
     await fixture.page.goto(newWindow.url())
     console.log("hello");
     
    await fixture.page.locator("//span[text()='Cypress']").hover()
})
    
    