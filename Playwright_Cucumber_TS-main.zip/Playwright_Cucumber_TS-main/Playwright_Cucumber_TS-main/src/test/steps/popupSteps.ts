import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../hooks/pageFixture";
import PopupPage from "../../pages/popupPage"


setDefaultTimeout(60 * 1000 * 2)

Given('User navigates to the practice-automation application', async function () {
    await fixture.page.goto(process.env.BASEURL);
    fixture.logger.info("Navigated to the application")
})

Given('User click on the popups link', async function () {
    await fixture.page.locator("//a[text()='Popups']").click();
});

When('User click on the Alert Popup button', async function () {
    await fixture.page.locator("//b[text()='Alert Popup']").click();
    await fixture.page.waitForLoadState();
    fixture.logger.info("Waiting for 2 seconds")
    await fixture.page.waitForTimeout(2000);
});


Then('Alert message should be display', async function () {
    await fixture.page.on("dialog", async (alert) => {
        const text = alert.message();
        console.log(text);;
        await alert.accept();
        fixture.logger.info("Waiting for 2 seconds")
        await fixture.page.waitForTimeout(2000);
    })
})
    
    