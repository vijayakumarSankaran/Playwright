import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";

import { expect } from "@playwright/test";
import { fixture } from "../../hooks/pageFixture";
import PopupPage from "../../pages/popupPage"


setDefaultTimeout(60 * 1000 * 2)

Given('User navigates to the practice-automation prompt application', async function () {
    await fixture.page.goto(process.env.BASEURL);
    fixture.logger.info("Navigated to the application")
})

Given('User click on the prompt link', async function () {
    await fixture.page.locator("//a[text()='Popups']").click();
});

When('User click on the Prompt Popup button', async function () {
    await fixture.page.locator("//b[text()='Prompt Popup']").click();
    await fixture.page.waitForLoadState();
    fixture.logger.info("Waiting for 2 seconds")
    await fixture.page.waitForTimeout(2000);
});

   
    Then('Prompt message should be display', async function () {
        await fixture.page.on('dialog', async dialog => {
    
            // Verify Dialog Type is prompt  
            expect(dialog.type()).toContain('prompt');  
            
            // Verify Dialog Message  
            expect(dialog.message()).toContain('Hi there, what');
            
            //Verify Default Input Value
            expect(dialog.defaultValue()).toContain('test');
            
            // Click on OK Button with any value
            await dialog.accept('test');
        });
            
        // Click on Prompt Button
        await fixture.page.click('#prompt-button');
            
        // Verify Message after clicking on Ok button
        await expect(fixture.page.locator('#msg')).toHaveText( 'Nice to meet you, test!')
    })